
const search = () => {
    const input = document.getElementById("search-item").value.toUpperCase();
    console.log(input)
    const product = document.querySelectorAll(".product-list .product")
    product.forEach(element => {
        const value = element.querySelector('h2').innerText.toUpperCase()
        if (value.indexOf(input) > -1) element.style.display = ""
        else element.style.display = "none"
    });

}